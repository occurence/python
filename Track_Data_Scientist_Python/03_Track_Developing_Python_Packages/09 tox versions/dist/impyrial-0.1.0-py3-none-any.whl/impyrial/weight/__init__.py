__doc__ = """
impyrial.weight
===============
Weight conversion between imperial units.
"""
from .api import convert_unit  # noqa : F401