#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Test basic Taggers."""

import unittest
from .. import NEChunker, POSTagger

from io import StringIO

class NERChunkerTest(unittest.TestCase):
  def __init__(self):
    pass

if __name__ == "__main__":
  unittest.main()
