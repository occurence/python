#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Test basic Transliterators facilities."""

import unittest
from .. import Transliterator

class TransliteratorTest(unittest.TestCase):
  def __init__(self):
    pass

if __name__ == "__main__":
  unittest.main()
