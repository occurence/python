#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_polyglot
----------------------------------

Tests for `polyglot` module.
"""

import unittest

from polyglot import polyglot


class TestPolyglot(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()